https://mitmachen.keinegrenzen.org

1-3 Alben, EPs, LPs, Mixtapes, …
Format: AAC (oder falls nicht anders möglich WAVE, AIFF, mp3)

Bitte jeweils in einen eigenen Ordner packen.
Zusätzlich jeweils das Cover in den entsprechenden Ordner.
Format: min. 500px * 500px, JPEG (so unkomprimiert wie möglich) oder PNG (ohne Transparenz)
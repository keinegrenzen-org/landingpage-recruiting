https://mitmachen.keinegrenzen.org

1x Profilbild, vorzugsweise mit Menschen als Motiv
Format: min. 600px * 400px, JPEG (so unkomprimiert wie möglich) oder PNG (ohne Transparenz).

1x Bannerbild
Format: min. 1920 * 1080px, JPEG (so unkomprimiert wie möglich) oder PNG (ohne Transparenz).